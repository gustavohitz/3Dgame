using Ebac.StateMachine;

public class GMStateIntro : StateBase {

    
    
}
